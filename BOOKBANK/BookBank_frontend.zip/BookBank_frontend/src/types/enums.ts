export const enum FireToastEnum {
  SUCCESS,
  WARNING,
  DANGER,
}
