# Book Bank - Admin Dashboard based on React using Tailwind and TailAdmin Template

This is the Git repository for Book Bank Admin dashboard built with **React, TypeScript and Tailwind CSS**, which let's you manage all books and users.

## Installation

You'll need to install Node.js >=v14.16+ (Recommended Version) (NPM comes along with it) and TailAdmin uses **Vite** for frontend tooling, to peform installation and building production version, please follow these steps from below:

- Use terminal and navigate to the project (tailadmin-react) root.

- Then run : <code>npm install</code>

- Then run : <code>npm run dev</code>

Now, in the browser go to <code>localhost:3000</code>

**For Production Build**
Run : <code>npm run build</code>

Default build output directory: /dist

This command will generate a dist as build folder in the root of your template that you can upload to your server.
